// Cloudflare Pages Function: POST /api/chat
// Requires a Workers AI binding named AI in Cloudflare Pages settings.
const SYSTEM_PROMPT = `You are Onyx AI, a friendly, careful everyday personal assistant.
Help users write, plan, brainstorm, summarise, and understand topics.
Be clear, kind, practical, and honest about uncertainty. Do not claim to have taken actions outside this chat.
Do not ask users to share passwords, payment card details, or highly sensitive personal information.
If asked for current information you cannot verify, say so. Keep replies concise but useful.`;

export async function onRequestPost({ request, env }) {
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff"
  };

  const json = (body, status = 200) =>
    new Response(JSON.stringify(body), { status, headers });

  if (!env.AI || typeof env.AI.run !== "function") {
    return json({ error: "AI binding is not configured. Add a Workers AI binding named AI and redeploy." }, 503);
  }

  let body;
  try {
    const contentLength = Number(request.headers.get("content-length") || 0);
    if (contentLength > 16000) return json({ error: "Message is too large." }, 413);
    body = await request.json();
  } catch {
    return json({ error: "Please send a valid message." }, 400);
  }

  if (!Array.isArray(body.messages) || body.messages.length < 1 || body.messages.length > 8) {
    return json({ error: "Please send between 1 and 8 recent messages." }, 400);
  }

  const messages = [];
  for (const item of body.messages) {
    if (!item || !["user", "assistant"].includes(item.role) ||
        typeof item.content !== "string" || !item.content.trim() ||
        item.content.length > 2000) {
      return json({ error: "A message is invalid or too long." }, 400);
    }
    messages.push({ role: item.role, content: item.content.trim() });
  }

  if (messages[messages.length - 1].role !== "user") {
    return json({ error: "Your latest message must be a user message." }, 400);
  }

  try {
    const result = await env.AI.run("@cf/meta/llama-3.1-8b-instruct", {
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        ...messages
      ],
      max_tokens: 700,
      temperature: 0.65
    });

    const reply = result && (result.response || result.result?.response);
    if (typeof reply !== "string" || !reply.trim()) {
      return json({ error: "The model returned an empty answer. Please try again." }, 502);
    }
    return json({ reply: reply.trim() });
  } catch (error) {
    // Avoid returning provider internals or secrets to the browser.
    return json({ error: "The AI service is temporarily unavailable or has reached its usage limit." }, 503);
  }
}

