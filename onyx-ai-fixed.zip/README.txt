# Onyx AI — fixed starter

This starter includes:
- `index.html`: responsive Onyx AI website and more robust chat UI.
- `functions/api/chat.js`: server-side chat endpoint for Cloudflare Pages Functions.
- Cloudflare Workers AI binding (`AI`) so no AI API key is placed in browser code.

## Important hosting note
GitHub Pages only serves static files and does not run the `/api/chat` server function. GitHub also says Pages is not intended for a commercial SaaS website. Use GitHub as the code repository, but deploy this project through Cloudflare Pages for the AI function.

## Deploy from an iPad

1. Download and unzip `onyx-ai-fixed.zip`.
2. In GitHub, create a new repository such as `onyx-ai`. Upload `index.html` and the `functions` folder, keeping the folder structure exactly:
   - `index.html`
   - `functions/api/chat.js`
3. Sign in to Cloudflare and open Workers & Pages.
4. Create a Pages project by connecting your GitHub repository. Choose the repository you just created.
5. For a plain HTML site, use no build command and set the build output directory to `.` if the setup screen asks for it. Deploy.
6. In Cloudflare, open your Pages project > Settings > Bindings > Add > Workers AI.
7. Set the variable name to exactly `AI`, save, and redeploy the project so the binding is active.
8. Open the `*.pages.dev` site and test: send “Give me three ideas to organise my day.”
9. If it fails, open Cloudflare > your Pages project > Functions/logs and check the reported error. The UI now shows a clear message rather than pretending a reply succeeded.

## Cost and safety
Cloudflare Workers AI currently documents a free daily allocation, with usage beyond it requiring a paid plan; limits and model availability can change. Check the current pricing page before public launch. Free is not unlimited.
- Keep the website in test mode until you add abuse prevention/rate limiting, clear privacy information, and a support contact.
- Do not collect passwords, payment details, or sensitive information in chat.
- Never put provider keys or secrets in `index.html`.
- The chat keeps a short conversation history in the browser memory only; it is not saved in a database by this starter.
- Do not advertise subscriptions or charge customers until billing, cancellations, terms, privacy and customer support are implemented.
- If you are under 18, have a parent/guardian help with account creation and any billing or business commitments.

## Official docs
- Pages Functions: https://developers.cloudflare.com/pages/functions/get-started/
- Workers AI binding: https://developers.cloudflare.com/pages/functions/bindings/
- Workers AI pricing: https://developers.cloudflare.com/workers-ai/platform/pricing/
- GitHub Pages limitations: https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits
